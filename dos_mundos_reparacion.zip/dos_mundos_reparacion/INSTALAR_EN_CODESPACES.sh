#!/usr/bin/env bash
set -euo pipefail
cd /workspaces/Dos-mundos-app-1
stamp=$(date +%Y%m%d-%H%M%S)
mkdir -p "respaldo-antes-reparacion-$stamp"
cp -a app/src/main/java app/src/main/AndroidManifest.xml app/build.gradle "respaldo-antes-reparacion-$stamp/" 2>/dev/null || true
rm -rf app/src/main/java/com/example/ui app/src/main/java/com/example/viewmodel app/src/main/java/com/example/model
cp -a /tmp/dos_mundos_reparacion/app/src/main/java/com/example/MainActivity.kt app/src/main/java/com/example/MainActivity.kt
cp /tmp/dos_mundos_reparacion/app/src/main/AndroidManifest.xml app/src/main/AndroidManifest.xml
cp /tmp/dos_mundos_reparacion/app/build.gradle app/build.gradle
./gradlew --stop || true
./gradlew :app:assembleDebug --no-daemon --max-workers=1 -Dorg.gradle.jvmargs='-Xmx768m -XX:MaxMetaspaceSize=384m' 
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
